package com.user;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBconn {

	public static String filepath="F:\\ProjectCode\\Final100%Code\\QRCode";
	public static String newfilepath="F:/ProjectCode/Final100%Code/QRCode";
	public static Connection conn() throws ClassNotFoundException, SQLException
	{
		Connection con;
		 Class.forName("com.mysql.jdbc.Driver");
		  con=DriverManager.getConnection("jdbc:mysql://localhost:3307/doc_ecertificateblockchain","root","admin");
		   
	return con;
	}

}
