package com.admin;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.sql.*;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mail.SendMail;
import com.qrcode.Create_QR;
import com.user.DBconn;

@WebServlet("/Accept")
public class Accept extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Accept() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String emailid = request.getParameter("emailid");
		PrintWriter pw = response.getWriter();
		String enrollment ="";
		try {
			BigInteger maxLimit = new BigInteger("510200890000");
			Random rand = new Random();
			BigInteger result = new BigInteger(maxLimit.bitLength(), rand);
			enrollment = String.valueOf(result);
			Connection con = (Connection) DBconn.conn();
			int flag=0;
			String Username = "";
			String msg="Accept Request";
			Statement stRegister12=(Statement) con.createStatement();
			 ResultSet rsLogin12=stRegister12.executeQuery("select * from updateprofile where emailid='" +emailid+ "'");
			 if(rsLogin12.next())
			 {
				 Username=rsLogin12.getString("firstname");
			 }
			Statement stRegister1=(Statement) con.createStatement();
			 ResultSet rsLogin1=stRegister1.executeQuery("select * from accept where emailid='" +emailid+ "'");
			 if(rsLogin1.next())
			 {
				 flag=1;
			 }
			 System.out.println("Flag=>"+flag);
			 if(flag==1)
			 {
				 Statement stRegister11=con.createStatement();
				stRegister11.executeUpdate("update accept set status='"+msg+"' where emailid='" +emailid+ "'");
				Statement stRegister101=con.createStatement();
				String acc="1";
				stRegister101.executeUpdate("update updateprofile set Status_Info='"+acc+"',Enrollment='"+enrollment+"' where emailid='" +emailid+ "'");
			 }
			 else{
		    String sql="insert into accept(emailid,status) values(?,?)";
			PreparedStatement p=(PreparedStatement) con.prepareStatement(sql);
			p.setString(1,emailid);
			p.setString(2, msg);
			
			p.executeUpdate();
			Statement stRegister101=con.createStatement();
			String acc="1";
			stRegister101.executeUpdate("update updateprofile set Status_Info='"+acc+"' where emailid='" +emailid+ "'");
			
			
			
			 }
			 File finalpath = new File(DBconn.filepath, Username);
				finalpath.mkdir();
				String path=DBconn.filepath+"\\"+Username+"\\"+Username+".png";
				System.out.println(path);
				//creating QR code
				String Enrollment_data=emailid+"#@"+enrollment;
				Create_QR.CreateQR(Enrollment_data,path);
				SendMail.SendImage(emailid,path);
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		
		pw.println("<html><script>alert('Status Update Successfully');</script><body>");
		pw.println("");
		pw.println("</body></html>");
		response.sendRedirect("NDataShow.jsp?Update");
				
	}

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
